//
//  ViewController.swift
//  expandableTableAppDemo
//
//  Created by iMac on 12/09/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var tableViwExpond: UITableView!
    
    //    var sections = [ItemList]()
    
    var prductData: [ItemList] = [
        ItemList(name: "MacBooks", items: [
            items(productName: "MacBook Air (M1, 2020)", productImage: UIImage(named: "ipadpro")!),
            items(productName: "MacBook pro 13 (M2, 2020)", productImage: UIImage(named: "macbookpro13")!)
        ]),
        ItemList(name: "iPads", items: [
            items(productName: "iPad", productImage: UIImage(named: "ipad")!),
            items(productName: "iPad Air 2", productImage: UIImage(named: "ipadpro")!)
        ]),
        ItemList(name: "iPhone", items: [
            items(productName: "iPhone X", productImage: UIImage(named: "ipadpro")!),
            items(productName: "iPhone 11", productImage: UIImage(named: "ipadpro")!),
            items(productName: "iPhone 12 Pro / 12 Pro Max", productImage: UIImage(named: "ipadpro")!),
            items(productName: "iPhone 13 Pro / 13 Pro Max", productImage: UIImage(named: "ipadpro")!),
            items(productName: "iPhone 14 / 14 Plus", productImage: UIImage(named: "ipadpro")!),
            items(productName: "iPhone 14 Pro / 14 Pro Max", productImage: UIImage(named: "iphone14promax")!)
        ]),
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        registerCell()
    }
    
    @objc func rightSwipwButtonTapped(_ sender:UIButton){
        
        var row = sender.tag % 1000
        var section = sender.tag / 1000
        
        guard let detailVC = self.storyboard?.instantiateViewController(withIdentifier: "detailsViewController") as? detailsViewController else{
            return
        }
        let selectedIndex = IndexPath(row: row, section: section)
        detailVC.data = prductData[selectedIndex.section].items[selectedIndex.row]
        
        self.navigationController?.pushViewController(detailVC, animated: true)
    }
}


//MARK: - Tableview Delegate and Datasource Method
extension ViewController : UITableViewDelegate,UITableViewDataSource{
    
    func registerCell(){
        self.tableViwExpond.register(UINib(nibName: "TableViewCell", bundle: nil), forCellReuseIdentifier: "TableViewCell")
    }
    
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 60
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView = UIView(frame: CGRect(x: 0, y: 0, width: self.view.frame.width, height: 60))
        let headerHeading = UILabel(frame: CGRect(x: 10, y: 10, width: headerView.frame.width - 10, height: headerView.frame.height - 20))
        let imageView = UIImageView(frame: CGRect(x: self.view.frame.width - 30, y: 20, width: 20, height: 20))
        
        if prductData[section].collapsed{
            imageView.image = UIImage(named: "collapsed")
        }else{
            imageView.image = UIImage(named: "expand")
        }
        
        let tapGuesture = UITapGestureRecognizer(target: self, action: #selector(headerViewTapped))
        tapGuesture.numberOfTapsRequired = 1
        headerView.addGestureRecognizer(tapGuesture)
        headerView.backgroundColor = .black
        headerView.tag = section
        headerHeading.text = prductData[section].name
        headerHeading.textColor = .white
        headerView.addSubview(headerHeading)
        headerView.addSubview(imageView)
        self.view.addSubview(headerView)
        return headerView
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return prductData.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let itms = prductData[section]
        return !itms.collapsed ? 0 : itms.items.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 40
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableViwExpond.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as? TableViewCell else {return .init()}
        cell.labelForData.text = prductData[indexPath.section].items[indexPath.row].productName
        cell.buttonRightSwipe.tag = (indexPath.section * 1000) + indexPath.row
        cell.buttonRightSwipe.addTarget(self, action: #selector(rightSwipwButtonTapped(_:)), for: .touchUpInside)
        return cell
    }
    
    @objc func headerViewTapped(tapped:UITapGestureRecognizer){
        print(tapped.view?.tag)
        if prductData[tapped.view!.tag].collapsed == true{
            prductData[tapped.view!.tag].collapsed = false
        }else{
            prductData[tapped.view!.tag].collapsed = true
        }
        if let imageView = tapped.view?.subviews[1] as? UIImageView{
            if imageView.isKind(of: UIImageView.self){
                if prductData[tapped.view!.tag].collapsed{
                    imageView.image = UIImage(named: "collapsed")
                }else{
                    imageView.image = UIImage(named: "expand")
                }
            }
        }
        
        
        
        tableViwExpond.reloadData()
    }
    
}
