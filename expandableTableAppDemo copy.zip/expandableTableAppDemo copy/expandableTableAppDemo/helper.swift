//
//  helper.swift
//  expandableTableAppDemo
//
//  Created by iMac on 12/09/22.
//

import Foundation
import UIKit

struct ItemList {
var name: String
var items: [items]
var collapsed: Bool

init(name: String, items: [items], collapsed: Bool = false) {
   self.name = name
   self.items = items
   self.collapsed = collapsed
   }
}

struct items{
    var productName:String
    var productImage:UIImage
}


