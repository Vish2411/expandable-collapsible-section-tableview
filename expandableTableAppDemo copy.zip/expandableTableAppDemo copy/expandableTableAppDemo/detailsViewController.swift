//
//  detailsViewController.swift
//  expandableTableAppDemo
//
//  Created by iMac on 12/09/22.
//

import UIKit

class detailsViewController: UIViewController {
    
    @IBOutlet weak var productImage: UIImageView!
    @IBOutlet weak var productName: UILabel!
    
    var data: items?

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if data == nil{
            print("Data Is Not Found")
        }else{
            self.productImage.image = data?.productImage
            self.productName.text  = data!.productName
        }
        
        // Do any additional setup after loading the view.
    }
    

}
