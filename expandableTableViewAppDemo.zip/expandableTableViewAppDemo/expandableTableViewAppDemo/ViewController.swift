//
//  ViewController.swift
//  expandableTableViewAppDemo
//
//  Created by iMac on 10/09/22.
//

import UIKit



class ViewController: UIViewController {
    
    @IBOutlet weak var expandableTableView: UITableView!
    
    private var sections = [Section]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        expandableTableView.delegate = self
        expandableTableView.dataSource = self
        cellRegister()
        setTableRow()
    }

    func setTableRow(){
        sections = [
            Section(title: "Section 1", options: [1,2,3].compactMap({return "Row \($0)"})),
            Section(title: "Section 2", options: [1,2,3].compactMap({return "Row \($0)"})),
            Section(title: "Section 3", options: [1,2,3].compactMap({return "Row \($0)"})),
            Section(title: "Section 4", options: [1,2,3].compactMap({return "Row \($0)"}))
        ]
    }

}

extension ViewController : UITableViewDelegate, UITableViewDataSource{
    
    private func cellRegister(){
        self.expandableTableView.register(UINib(nibName: "TableViewCell", bundle: nil), forCellReuseIdentifier: "TableViewCell")
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return sections.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let section = sections[section]
        if section.isOpened {
            return section.options.count + 1
        }else{
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = expandableTableView.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as? TableViewCell else { return .init()}
        
        if indexPath.row == 0{
            cell.labeltext.text = sections[indexPath.section].title
//            cell.sideImage.image = UIImage(named: "down")
        }else{
            cell.labeltext.text = sections[indexPath.section].options[indexPath.row - 1]
            cell.sideImage.isHidden = true
        }
        
        
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 51
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        expandableTableView.deselectRow(at: indexPath, animated: true)
        //        if indexPath.row == 0{
        //    }else{
        //            print("Tapped cell")
        //        }
        
        guard let cell = tableView.cellForRow(at: indexPath) as? TableViewCell else{
               return
             }
        
        sections[indexPath.section].isOpened = !sections[indexPath.section].isOpened
        
        
//        if sections[indexPath.section].isOpened == true{
//            if indexPath.row == 0{
//                cell.sideImage.image = UIImage(named: "des")
//            }else{
//                cell.sideImage.isHidden = true
//            }
//        }else{
//            if indexPath.row == 0{
//                cell.sideImage.image = UIImage(named: "down")
//            }else{
//                cell.sideImage.isHidden = true
//            }
//        }
//        expandableTableView.reloadSections(<#T##sections: IndexSet##IndexSet#>, with: <#T##UITableView.RowAnimation#>)
        expandableTableView.reloadSections([indexPath.section], with: .bottom)
    }
}
